#!/usr/bin/env python

import application

a = application.Application()
a.run()

